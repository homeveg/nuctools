$in_file = shift;
$filesize = -s $in_file; #determine file size in bytes
$filesize = int($filesize/(1024*1024) ); # filesize in megabytes
print $filesize,"\n";