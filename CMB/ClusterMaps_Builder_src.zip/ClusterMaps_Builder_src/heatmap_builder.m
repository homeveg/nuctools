function varargout = heatmap_builder(varargin)
% HEATMAP_BUILDER MATLAB code for heatmap_builder.fig
%      HEATMAP_BUILDER, by itself, creates a new HEATMAP_BUILDER or raises the existing
%      singleton*.
%
%      H = HEATMAP_BUILDER returns the handle to a new HEATMAP_BUILDER or the handle to
%      the existing singleton*.
%
%      HEATMAP_BUILDER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HEATMAP_BUILDER.M with the given input arguments.
%
%      HEATMAP_BUILDER('Property','Value',...) creates a new HEATMAP_BUILDER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before heatmap_builder_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to heatmap_builder_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help heatmap_builder

% Last Modified by GUIDE v2.5 07-Jan-2017 19:34:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @heatmap_builder_OpeningFcn, ...
                   'gui_OutputFcn',  @heatmap_builder_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

try
    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
catch err
   msgString = getReport(err, 'extended');
   errordlg( msgString, 'Warning!');  
end


% End initialization code - DO NOT EDIT
end

%% Initialize all elements of GUI

% --- Executes just before heatmap_builder is made visible.
function heatmap_builder_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to heatmap_builder (see VARARGIN)
handles.output = hObject;
handles.current_dir = getuserdir();
handles.pdf = 'ClusterMaps_Builder_Manual_v3.pdf';
% load settings file
settings_file=fullfile(handles.current_dir,'settings.mat');
if exist(settings_file, 'file') == 2
    load(settings_file, 'handles');
else
        
% Choose default command line output for heatmap_builder
    handles.sort_options = 1;
    handles.smooth = 1;
    handles.do_not_normalize = 0;
    handles.use_norm = 3;
    handles.sort = 0;
    handles.save_clusters = 1;
    handles.delta_weight = 500;
    handles.sorting_shift = 0;
    handles.nr_of_clusters = 5;
    handles.nr_of_itterations = 1;
    handles.use_cmap = 'bone';
    handles.save_sorting_order = 1;
    handles.remember_clustering = 1;
    handles.treshold = 1;
    handles.apply_xlim = 0;
    handles.xlim_up = 2000;

end
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes heatmap_builder wait for user response (see UIRESUME)
% uiwait(handles.heatmap_builder);
end

% --- Outputs from this function are returned to the command line.
function varargout = heatmap_builder_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
end

% --- Executes during object creation, after setting all properties.
function Heatmap_title_field_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Heatmap_title_field (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


% --- Executes during object creation, after setting all properties.
function Sorting_options_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sorting_options (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
guidata(hObject, handles);
end

% --- Executes during object creation, after setting all properties.
function enter_delta_CreateFcn(hObject, eventdata, handles)
% hObject    handle to enter_delta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% Update handles structure
guidata(hObject, handles);
end


% --- Executes during object creation, after setting all properties.
function enter_shift_CreateFcn(hObject, eventdata, handles)
% hObject    handle to enter_shift (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% Update handles structure
guidata(hObject, handles);
end


% --- Executes during object creation, after setting all properties.
function enter_nr_of_clusters_CreateFcn(hObject, eventdata, handles)
% hObject    handle to enter_nr_of_clusters (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% Update handles structure
guidata(hObject, handles);
end

% --- Executes during object creation, after setting all properties.
function enter_nr_of_itterations_CreateFcn(hObject, eventdata, handles)
% hObject    handle to enter_nr_of_itterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


% --- Executes during object creation, after setting all properties.
function popupmenu6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

% --- Executes during object creation, after setting all properties.
function Enter_Upper_XLim_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Enter_Upper_XLim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


% --- Executes during object creation, after setting all properties.
function enter_treshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to enter_treshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% Start Analysis

% --- Executes on button press in checkbox_do_not_normalize.
function checkbox_do_not_normalize_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_do_not_normalize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_do_not_normalize
value = get(hObject,'Value');
if value == 0 
    handles.do_not_normalize = 0;
else 
    handles.do_not_normalize = 1;
end
msg=sprintf('Do not normalize: %d', handles.do_not_normalize);
disp(msg);
guidata(gcbo, handles);
end


function enter_delta_Callback(hObject, eventdata, handles)
% hObject    handle to enter_delta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of enter_delta as text
%        str2double(get(hObject,'String')) returns contents of enter_delta as a double
value = str2double(get(hObject,'String'));
if value >= 0,
    handles.delta_weight = value;
else
    h=msgbox('Wrong value for delta! Using default value (200)','Warning:','warn');
    handles.delta_weight = 200;
end
msg=sprintf('Size of a focus window %d', handles.delta_weight);
disp(msg);
guidata(gcbo, handles);
end


function enter_shift_Callback(hObject, eventdata, handles)
% hObject    handle to enter_shift (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of enter_shift as text
%        str2double(get(hObject,'String')) returns contents of enter_shift as a double
handles.sorting_shift = str2double(get(hObject,'String'));
msg=sprintf('Shift center of focus window to %d', handles.sorting_shift);
disp(msg);
guidata(gcbo, handles);
end

% --- Executes when selected object is changed in Sorting_options.
function Sorting_options_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in Sorting_options 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

    switch get(eventdata.NewValue,'Tag')
        case 'radiobutton_DoNotSort'
            handles.sort_options = 0; % do not sort
        case 'radiobutton_Use_Avegrage'
            handles.sort_options = 1; %use average
        case 'radiobutton_Use_StDev'
            handles.sort_options = 2; % use 'StDev';
        case 'radiobutton_Use_Col2'
            handles.sort_options = 3; % use 'Log2ratios';
        case 'radiobutton_Arrange_nuc'
            handles.sort_options = 4; % perform K-mean clustering
        case 'radiobutton_Reuse_saved_sorting'
            handles.sort_options = 5; % reuse saved sorting order
        case 'radiobutton_hierar_clust'
            handles.sort_options = 6; % reuse saved sorting order
        otherwise
            handles.sort_options = 1;
    end
    msg=sprintf('Apply analysis option %d', handles.sort_options);
    disp(msg);
    guidata(gcbo, handles);
end



function enter_nr_of_clusters_Callback(hObject, eventdata, handles)
% hObject    handle to enter_nr_of_clusters (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of enter_nr_of_clusters as text
%        str2double(get(hObject,'String')) returns contents of enter_nr_of_clusters as a double
 
value = str2double(get(hObject,'String'));
if value > 0,
    handles.nr_of_clusters = value;
else
    h=msgbox('Nr. of clusters should be bigger than 0! Using default value (5)','Warning:','warn');
    handles.nr_of_clusters = 5;
end
msg=sprintf('Expected Nr. of clusters (K-mean): %d', handles.nr_of_clusters);
disp(msg);
guidata(gcbo, handles);
end


% --- Executes on button press in checkbox_sort.
function checkbox_sort_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_sort (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_sort
value = get(hObject,'Value');
if value == 1 
    handles.sort = 1;
else 
    handles.sort = 0;
end
msg=sprintf('Sort profiles incide clusters (K-mean): %d', handles.sort);
disp(msg);
guidata(gcbo, handles);
end


% --- Executes on button press in save_clusters.
function save_clusters_Callback(hObject, eventdata, handles)
% hObject    handle to save_clusters (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of save_clusters
value = get(hObject,'Value');
if value == 1 
    handles.save_clusters = 1;
else 
    handles.save_clusters = 0;
end
msg=sprintf('Save clusters (K-mean): %d', handles.save_clusters);
disp(msg);
guidata(gcbo, handles);
end



function enter_nr_of_itterations_Callback(hObject, eventdata, handles)
% hObject    handle to enter_nr_of_itterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of enter_nr_of_itterations as text
%        str2double(get(hObject,'String')) returns contents of enter_nr_of_itterations as a double
value = str2double(get(hObject,'String'));
if value > 0,
    handles.nr_of_itterations = value;
else
    h=msgbox('Nr. of K-mean clustering itteration should be bigger than 0! Using default value (3)','Warning:','warn');
    handles.nr_of_itterations = 3;
end
msg=sprintf('Nr. of itterations (K-mean): %d', handles.nr_of_itterations);
disp(msg);
guidata(gcbo, handles);
end


% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5
selection = get(handles.popupmenu5,'Value');
switch selection
    case 2
        handles.use_cmap = 'bone';
    case 3
        handles.use_cmap = 'blue_cmap';
    case 4
        handles.use_cmap = 'red_cmap';
    case 5
        handles.use_cmap = 'jet';
    case 6
        handles.use_cmap = 'bone_invert';
    case 7
        handles.use_cmap = 'blue_invert';
    case 8
        handles.use_cmap = 'red_invert';
        
end
msg=sprintf('Colour scheme %s seleted', handles.use_cmap);
disp(msg);
guidata(gcbo, handles);
end


% --- Executes on button press in smoothing.
function smoothing_Callback(hObject, eventdata, handles)
% hObject    handle to smoothing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of smoothing
value = get(hObject,'Value');
if value == 0 
    handles.smooth = 1;
else 
    handles.smooth = 0;
end
msg=sprintf('Apply data smothing for visualisation: %d', handles.smooth);
disp(msg);
guidata(gcbo, handles);
end


% --- Executes on button press in save_sorting_order.
function save_sorting_order_Callback(hObject, eventdata, handles)
% hObject    handle to save_sorting_order (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of save_sorting_order
handles.save_sorting_order = get(hObject,'Value');
msg=sprintf('Save sorting order: %d', handles.save_sorting_order);
disp(msg);
guidata(gcbo, handles);
end


% --- Executes on selection change in popupmenu6.
function popupmenu6_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu6 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu6
selection = get(handles.popupmenu6,'Value');
switch selection
    case 2
        handles.use_norm = 'rescale';
    case 3
        handles.use_norm = 'rescale_each';
    case 4
        handles.use_norm = 'maximum';
    case 5
        handles.use_norm = 'global_max';
    case 6
        handles.use_norm = 'leftmost';
    case 7
        handles.use_norm = 'treshold';    
    case 8
        handles.use_norm = 'none';
    

end
msg=sprintf('Normalization method %d (%s) seleted', selection, handles.use_norm);
disp(msg);
guidata(gcbo, handles);
end



function enter_treshold_Callback(hObject, eventdata, handles)
% hObject    handle to enter_treshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of enter_treshold as text
%        str2double(get(hObject,'String')) returns contents of enter_treshold as a double
value = str2double(get(hObject,'String'));
if value > 0,
    handles.treshold = value;
else
    h=msgbox('Upper treshold value should be bigger than 0. Set to default value (1)','Warning:','warn');
    handles.treshold = 1;
end
msg=sprintf('Set a Y treshold to %d', handles.treshold);
disp(msg);
guidata(gcbo, handles);
end


% --- Executes on button press in Upper_Xlim.
function Upper_Xlim_Callback(hObject, eventdata, handles)
% hObject    handle to Upper_Xlim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of Upper_Xlim
handles.apply_xlim = get(hObject,'Value');
msg=sprintf('Apply upper X limit: %d', handles.apply_xlim);
disp(msg);
guidata(gcbo, handles);
end


function Enter_Upper_XLim_Callback(hObject, eventdata, handles)
% hObject    handle to Enter_Upper_XLim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Enter_Upper_XLim as text
%        str2double(get(hObject,'String')) returns contents of Enter_Upper_XLim as a double
value = str2double(get(hObject,'String'));
if value > 0,
    handles.xlim_up = value;
else
    h=msgbox('Upper treshold value should be bigger than 0. Set to default value (2000)','Warning:','warn');
    handles.xlim_up = 2000;
end
msg=sprintf('Display first %d values', handles.xlim_up);
disp(msg);
guidata(gcbo, handles);
end


% --- Executes on button press in Load_sorting.
function Load_sorting_Callback(hObject, eventdata, handles)
% hObject    handle to Load_sorting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    [FileName, PathName] = uigetfile({'*.mat';'*.*'},'Open saved sorting order (mat file)', path);
    pattern = '(?:sorting_order\.|cluster_order\.)(.*\.mat)';
    name = regexp(FileName, pattern, 'tokens');
    name_ext=char(name{1});
    
    handles.sorting_order_filename = sprintf('%s%s%s',PathName,'sorting_order.',name_ext);
    handles.cluster_order_filename = sprintf('%s%s%s',PathName,'cluster_order.',name_ext);  
    msg= sprintf('%s%s', 'sorting order loaded: ',name_ext);
    statusbar(heatmap_builder,msg);
    set(handles.sorting_order_info_text,'String',msg);

    guidata(gcbo, handles);

end


% --- Executes on button press in Save_sorting.
function Save_sorting_Callback(hObject, eventdata, handles)
% hObject    handle to Save_sorting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName, PathName]=uiputfile({'*.mat';'*.*' },'Save sorting order to mat file',handles.InFileName)
sb = statusbar(heatmap_builder,' ');
if isequal(FileName,0) || isequal(PathName,0)
    set(handles.file_path_field,'String','Sorting order file was not saved!');
else
    OutFileName=fullfile(PathName,FileName);
    handles.sorting_order_filename = sprintf('%s%s%s',PathName,'sorting_order.',FileName);
    handles.cluster_order_filename = sprintf('%s%s%s',PathName,'cluster_order.',FileName);

   statusbar(heatmap_builder,'save sorting order...');

   saved_Sorting_order=handles.Sorting_order;
   save(handles.sorting_order_filename, 'saved_Sorting_order');
   disp('Contents of sorting_order.mat:');
   whos('-file', handles.sorting_order_filename);

   if handles.sort_options == 4,
        saved_clusters_order=handles.SortedClusters;
        save(handles.cluster_order_filename, 'saved_clusters_order');
        disp('Contents of clusters_order.mat:');
        whos('-file', handles.cluster_order_filename);
   end
    
    msg= sprintf('%s%s', 'sorting order file saved to: ',OutFileName);
    statusbar(heatmap_builder,msg);
    set(handles.sorting_order_info_text,'String',msg);
end

% save analysis settings
savefile=fullfile(handles.current_dir,'settings.mat');
save(savefile,'-struct','handles',...      
    'sort_options','smooth','do_not_normalize',...      
    'use_norm','sort','save_clusters','delta_weight',...      
    'sorting_shift','sorting_shift','nr_of_clusters',...      
    'nr_of_itterations','use_cmap','save_sorting_order',...      
    'remember_clustering','treshold','apply_xlim','xlim_up');     
disp('Contents of settings.mat:');
whos('-file', savefile);

guidata(gcbo, handles);
end


% --- Executes on button press in restore_clusters.
function restore_clusters_Callback(hObject, eventdata, handles)
% hObject    handle to restore_clusters (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of restore_clusters
value = get(hObject,'Value');
if value == 0 
   handles.remember_clustering = 0;
else 
   handles.remember_clustering = 1;
end
msg=sprintf('Restore clustering order: %d', handles.remember_clustering);
disp(msg);
guidata(gcbo, handles);
end

% --------------------------------------------------------------------
function Open_Matrix_File_Callback(hObject, eventdata, handles)
% hObject    handle to Open_Matrix_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% check for old path
path='';
handles_fieldnames = fieldnames(handles);
for cnum = 1:length(handles_fieldnames)
    field_name=handles_fieldnames{cnum};
    if isequal(field_name,'PathName')
        path = handles.PathName;
    end
end

sb = statusbar(heatmap_builder,'loading matrix');
[FileName, PathName] = uigetfile({'*.txt';'*.dat';'*.matrix';'*.*'},'Open frequency distribution matrix', path);

if isequal(FileName,0) || isequal(PathName,0)
    set(handles.file_path_field,'String','matrix has not been selected');
    set(sb.TextPanel,'matrix has not been selected');
    handles.matrix_loaded=0;
else
    handles.matrix_loaded = 1;
    % Full path to a matrix file
    InFileName=fullfile(PathName,FileName);
    handles.InFileName=InFileName;
    handles.PathName=PathName;

    msg= sprintf('%s%s%s', 'Determine file size and number of strings/columns in ', FileName,'. Please wait...');
    progressbar('loading matrix');
    progressbar(0.01);
    sb=statusbar(heatmap_builder,msg);

    % set(sb.ProgressBar, 'Visible','on', 'Value', 35, 'StringPainted', 'on','string',' ');
    % load the file
    % extract nr of strings;
    % unix_filepath= sprintf('%s%s%s', '"', InFileName,'"');
    % nrows = str2num( perl('countlines.pl', unix_filepath) );
    progressbar(0.1);

    % check file size;
    % filesize = str2num( perl('file_size.pl', unix_filepath) );

    progressbar(0.2);
    
    % msg= sprintf('%s%u%s%s%s%.2f%s', 'loading ', nrows, ' strings from ', FileName,' (',filesize,' Mbs)');
    msg= sprintf('%s%s%s', 'loading ', FileName, '. Please wait...' );
    statusbar(heatmap_builder,msg);
    % set(sb.ProgressBar, 'Visible','on', 'Value', 70, 'StringPainted', 'on');
    progressbar(0.3);

    fid=fopen(InFileName,'rt'); %source file
    %read first string to get nr. of columns
    str=fgetl(fid);
    values = textscan (str,'%s');
    [noEntries, noNuc] = size(values{1,1});
    status=fclose(fid);    
    
    %generate format string for textscan
    formatString=repmat({'%f'},1,noEntries-2);
    outputFormatString=repmat({'%f\t'},1,noEntries-3);
    progressbar(0.4);

    formatString2=cell2mat(formatString);
    Output_formatString2=cell2mat(outputFormatString);
    newformatString=sprintf('%s%s','%s%f',formatString2);
    new_outputFormatString=sprintf('%s%s%s','%f\t%f\t',Output_formatString2,'%s\n');
    progressbar(0.5);

    %load file
    % data=textscan(fid,newformatString,nrows,'headerlines',0,'delimiter','\t','CollectOutput',true,'EndOfLine','\r\n'); % Option is MATLAB 7.4 feature
    data=readtable(InFileName,'Delimiter','\t', ...
    'Format',newformatString);
    progressbar(0.6);

    handles.Transcript_IDs=data(:,1);
    handles.Column2=table2array(data(:,2));
    handles.OutputFormatString = new_outputFormatString;
    progressbar(0.7);

    [noEntries, noNuc] = size(data);
    handles.noEntries = noEntries;
    
    handles.chr=table2array(data(1:noEntries,3:noNuc));

    handles.noNuc = noNuc-2;
    
    progressbar(1);

    if handles.noEntries <= 1 || handles.noNuc <= 1
        h=msgbox('Wrong matrix file! Please use tab-delimited text tables with as minimum 2 columns and rows','Warning:','warn');
        msg= sprintf('%s', 'Wrong matrix file! File not loaded...');
        statusbar(heatmap_builder,msg);
        %set(sb.ProgressBar, 'Visible','on', 'Value', 0, 'StringPainted', 'on');
    else
        msg= sprintf('input file loaded: %s\n%d x %d elements', handles.InFileName, handles.noNuc, handles.noEntries);
        statusbar(heatmap_builder,'file loaded');
        set(sb.ProgressBar, 'Value', 100);
        set(handles.Start_analysis(1),'Enable','on')
        set(handles.Start_analysis(2),'Enable','on')
    end
    set(handles.file_path_field,'String', msg);
end

guidata(gcbo, handles);
end

% --------------------------------------------------------------------
function Open_Matrix_File_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to Open_Matrix_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% check for old path
path='';
handles_fieldnames = fieldnames(handles);
for cnum = 1:length(handles_fieldnames)
    field_name=handles_fieldnames{cnum};
    if isequal(field_name,'PathName')
        path = handles.PathName;
    end
end

sb = statusbar(heatmap_builder,'loading matrix');
[FileName, PathName] = uigetfile({'*.txt';'*.dat';'*.matrix';'*.*'},'Open frequency distribution matrix', path);

if isequal(FileName,0) || isequal(PathName,0)
    set(handles.file_path_field,'String','matrix has not been selected');
    set(sb.TextPanel,'matrix has not been selected');
    handles.matrix_loaded=0;
else
    handles.matrix_loaded = 1;
    % Full path to a matrix file
    InFileName=fullfile(PathName,FileName);
    handles.InFileName=InFileName;
    handles.PathName=PathName;

    msg= sprintf('%s%s%s', 'Determine file size and number of strings/columns in ', FileName,'. Please wait...');
    progressbar('loading matrix');
    set(sb.ProgressBar, 'Value', 0);  
    sb=statusbar(heatmap_builder,msg);

    % set(sb.ProgressBar, 'Visible','on', 'Value', 35, 'StringPainted', 'on','string',' ');
    % load the file
    % extract nr of strings;
    % unix_filepath= sprintf('%s%s%s', '"', InFileName,'"');
    % nrows = str2num( perl('countlines.pl', unix_filepath) );
    set(sb.ProgressBar, 'Value', 10);  
    progressbar(0.1);

    % check file size;
    % filesize = str2num( perl('file_size.pl', unix_filepath) );

    set(sb.ProgressBar, 'Value', 20);  
    progressbar(0.2);

    % msg= sprintf('%s%u%s%s%s%.2f%s', 'loading ', nrows, ' strings from ', FileName,' (',filesize,' Mbs)');
    msg= sprintf('%s%s%s', 'loading ', FileName, '. Please wait...' );
    statusbar(heatmap_builder,msg);
    % set(sb.ProgressBar, 'Visible','on', 'Value', 70, 'StringPainted', 'on');
    set(sb.ProgressBar, 'Value', 30);  
    progressbar(0.3);

    fid=fopen(InFileName,'rt'); %source file
    %read first string to get nr. of columns
    str=fgetl(fid);
    values = textscan (str,'%s');
    [noEntries, noNuc] = size(values{1,1});
    status=fclose(fid);    

    %generate format string for textscan
    formatString=repmat({'%f'},1,noEntries-2);
    outputFormatString=repmat({'%f\t'},1,noEntries-3);
    set(sb.ProgressBar, 'Value', 40);  
    progressbar(0.4);

    formatString2=cell2mat(formatString);
    Output_formatString2=cell2mat(outputFormatString);
    newformatString=sprintf('%s%s','%s%f',formatString2);
    new_outputFormatString=sprintf('%s%s%s','%f\t%f\t',Output_formatString2,'%s\n');
    set(sb.ProgressBar, 'Value', 50);  
    progressbar(0.5);

    %load file
    % data=textscan(fid,newformatString,nrows,'headerlines',0,'delimiter','\t','CollectOutput',true,'EndOfLine','\r\n'); % Option is MATLAB 7.4 feature
    data=readtable(InFileName,'Delimiter','\t', ...
    'Format',newformatString);
    set(sb.ProgressBar, 'Value', 60);  
    progressbar(0.6);

    handles.Transcript_IDs=data(:,1);
    handles.Column2=table2array(data(:,2));
    handles.OutputFormatString = new_outputFormatString;
    set(sb.ProgressBar, 'Value', 70);  
    progressbar(0.7);

    [noEntries, noNuc] = size(data);
    handles.noEntries = noEntries;
    
    handles.chr=table2array(data(1:noEntries,3:noNuc));

    handles.noNuc = noNuc-2;
    
    set(sb.ProgressBar, 'Value', 100);  
    progressbar(1);

    if handles.noEntries <= 1 || handles.noNuc <= 1
        h=msgbox('Wrong matrix file! Please use tab-delimited text tables with as minimum 2 columns and rows','Warning:','warn');
        msg= sprintf('%s', 'Wrong matrix file! File not loaded...');
        statusbar(heatmap_builder,msg);
        %set(sb.ProgressBar, 'Visible','on', 'Value', 0, 'StringPainted', 'on');
    else
        msg= sprintf('input file loaded: %s\n%d x %d elements', handles.InFileName, handles.noNuc, handles.noEntries);
        statusbar(heatmap_builder,'file loaded');
        set(sb.ProgressBar, 'Value', 100);
        set(handles.Start_analysis(1),'Enable','on')
        set(handles.Start_analysis(2),'Enable','on')
    end
    set(handles.file_path_field,'String', msg);
end
guidata(gcbo, handles);
end

% --------------------------------------------------------------------
function Start_analysis_Callback(hObject, eventdata, handles)
% hObject    handle to Start_analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


    %initialize
    noEntries = handles.noEntries;
    noNuc = handles.noNuc;
    chr = handles.chr;
    Transcript_IDs = handles.Transcript_IDs;
    Column2 = handles.Column2;
    sb = statusbar(heatmap_builder,' ');

    handles.SmoothedGenes = zeros(1,handles.noEntries);
    handles.Column2(isnan(handles.Column2)) = 1000 ;
	handles.maximum = max(max(chr));
    handles.minimum = min(min(chr));
    statusbar(heatmap_builder,'normalization...');
    set(sb.ProgressBar, 'Value', 20);
     
    % normalize
    
    selection = handles.use_norm
    switch selection
    case 'rescale_each'
        progressbar('Rescaling each lane from 0 to 1 ...');
        for i = 1 : handles.noEntries
            maximum = max(chr(i,:));
            minimum = min(chr(i,:));
            chr(i,:) = ( chr(i,:) - minimum) / (maximum-minimum);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);
    
    case 'rescale'
        progressbar('Rescaling matrix from 0 to 1 ...');
        maximum = max(max(handles.chr));
        minimum = min(min(handles.chr));
        for i = 1 : handles.noEntries
            chr(i,:) = ( chr(i,:) - minimum) / (maximum-minimum);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);
        
    case 'maximum'
        progressbar('Normalize to a maximum...');
        for i = 1 : handles.noEntries
            maximum = max(chr(i,:));
            chr(i,:) = ( chr(i,:)) / (maximum);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);
        
    case 'global_max'
        progressbar('Normalize to a gloabal maximum...');
        maximum = max(max(handles.chr));
        for i = 1 : handles.noEntries
            chr(i,:) = ( chr(i,:)) / (maximum);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = maximum;
        handles.minimum = min(min(chr));
        progressbar(1);
        
    case 'leftmost';
        progressbar('Normalize to most left value ...');
        for i = 1 : handles.noEntries
            chr(i,:) =  chr(i,:) / chr(i,1);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);
        
    case 'treshold';
        progressbar('Remove values above a treshold...');
        for i = 1 : handles.noEntries
            for j = 1: handles.noNuc
               if chr(i,j) > handles.treshold,
                chr(i,j) = handles.treshold;
               end
            end
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);

    case 'none';
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
    end
    
    %plot normalized average occupancy profile
    AV2=nanmean(chr);

    maxTick=noNuc-5;
    half_TickX=round((noNuc-1)/2, -1);
    one_forth_tickX = round((noNuc-1)/4, -1);
    three_forth_tickX = round(3*(noNuc-1)/4, -1);

    % set(figure, 'MenuBar', 'none');
    x_size=700;
    y_size=600;
    bottom=100;
    left=100;
    h=figure('Position', [left, bottom, x_size+50, y_size]);
    
    plot(AV2(1,1:noNuc),'DisplayName','Average profile','YDataSource','AV2(1,1:noNuc)','LineWidth',2);
    if handles.apply_xlim == 1,
       xlim([0 handles.xlim_up]);
    else
       xlim([0 noNuc]);
    end

    set(gca, 'XTick', [1 one_forth_tickX half_TickX three_forth_tickX maxTick] );
    set(gca, 'XTickLabel', {-half_TickX,-one_forth_tickX,0,one_forth_tickX, half_TickX } );
    xlabel('Distance from feature (bp)');
    ylabel('Normalized signal');

     % save individual cluster's metagenes as PNG
    png_path = sprintf('%s%s%s%s', handles.PathName, 'aggregated_profile', '.png');
    print(h, '-dpng','-r300', png_path);


    chr(isnan(chr)) = 0.000000000001 ;

    % prepare data to plot
    % Sort genes in increasing order of the standard deviation of occupancy
    if handles.delta_weight > round((handles.noNuc-1)/2),
        msg = sprintf ('Delta can not be bigger than 1/2 of array widht!\nReplacing current value %d by %d', handles.delta_weight, round((handles.noNuc-1)/2)-1);
        handles.delta_weight = round((handles.noNuc-1)/2)-1;
        disp(handles.delta_weight);
        guidata(gcbo, handles);
    end

    if handles.delta_weight > 0,
        statusbar(heatmap_builder,'sorting according to a weight...');
        set(sb.ProgressBar, 'Value', 40);

        weight_delta=handles.delta_weight;
        shift = handles.sorting_shift;

        start_region = round((handles.noNuc-1)/2)+shift-weight_delta;
        stop_region = round((handles.noNuc-1)/2)+shift+weight_delta+1;
        Weight = zeros(1,handles.noEntries);
        
        if exist ('handles.Sorting_order' , 'var'),
            Sorting_order = handles.Sorting_order;
        else 
            Sorting_order = zeros(1,handles.noEntries);
        end
        
        id = zeros(1,handles.noEntries);

        % initialize sorting order (handles.sort_options = 0)
        progressbar('indexing...');
        for i = 1 : handles.noEntries
            Sorting_order(i) = i;
            Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
            progressbar(i/handles.noEntries);
        end
        
        % do not sort
        if handles.sort_options == 0,
             [Ordered, id] = sort(Sorting_order);
             handles.remember_clustering = 0;
        
        % use average
        elseif handles.sort_options == 1,
            statusbar(heatmap_builder,'calcualting average frequency in [-delta..+delta] region...');
            progressbar('calcualting average frequency in [-delta..+delta] region...');
            for i = 1 : handles.noEntries
                Sorting_order(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                progressbar(i/handles.noEntries);
            end
            [Ordered, id] = sort(Sorting_order);
            handles.remember_clustering = 0;
            
        % use 'StDev';
        elseif handles.sort_options == 2,
            statusbar(heatmap_builder,'calcualting St.Dev of frequency in [-delta..+delta] region...');
            progressbar('calcualte St.Dev of frequency in [-delta..+delta] region...');
            for i = 1 : handles.noEntries
                Sorting_order(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                progressbar(i/handles.noEntries);
            end
            [Ordered, id] = sort(Sorting_order);
            handles.remember_clustering = 0;
            
        % use data from col 2 to sort';    
        elseif handles.sort_options == 3,
            statusbar(heatmap_builder,'use column 2 for sorting...');
            Weight=Column2;
            tmp=transpose(Weight);
            Weight=tmp;
            [Ordered, id] = sort(Weight);
            handles.remember_clustering = 0;
            
        % use K-mean clustering; 
        elseif handles.sort_options == 4,
            statusbar(heatmap_builder,'perform K-mean clustering');
            progressbar('perform K-mean clustering');
            tic
            opts = statset('Display','final');
            [membership, ctrs, sumd, pointd] = kmeans(chr(1:handles.noEntries, start_region:stop_region),handles.nr_of_clusters,...
                        'emptyaction','drop',...
                        'Replicates',handles.nr_of_itterations,...
                        'Options',opts);
            handles.non_zero_indexes=find(sumd)
            [identified_clusters,cols]=size(handles.non_zero_indexes)
            msg = sprintf ('K-mean clustering done in %f seconds. %d clusters identifid', toc, identified_clusters);
            disp(msg);
            progressbar(1);
            statusbar(heatmap_builder,'indexing...');
            progressbar('indexing...');
            for i = 1 : handles.noEntries
                Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                Sorting_order(i) = membership(i);
                if handles.sort ~= 0,
                    NewSorting_order(i,1) = membership(i);
                    NewSorting_order(i,2) = Weight(i);
                end
                progressbar(i/handles.noEntries);
            end
            
            if handles.save_sorting_order == 1,
                handles.remember_clustering = 1;
            else 
                handles.remember_clustering = 0;
            end
            
            if handles.sort == 1,
                [Ordered, id] = sortrows(NewSorting_order, [1,2]);
            else
                [Ordered, id] = sort(Sorting_order);
            end
            SortedClusters = membership(id, :);
            handles.clusters_order = SortedClusters;
            
        % use hierarchical clustering; 
        elseif handles.sort_options == 6,
            statusbar(heatmap_builder,'Compute hierarchical clustering');
            progressbar('Compute hierarchical clustering');
            cmap_selection = handles.use_cmap
 
            c = clustergram(chr,...
                        'Cluster','column',...
                        'ColumnPDist', 'ward',...
                        'Linkage', 'complete',...
                        'OptimalLeafOrder', 'TRUE',...
                        'colormap', cmap_selection,...
                        'Dendrogram',1,...
                        'Symmetric', 'FALSE' );
                    
            clust_order=get(c, 'RowLabels')
            transposed = clust_order'
            clust_order= str2double(transposed)
            msg = sprintf ('Hierarchical clustering done in %f seconds.', toc);
            disp(msg);
            progressbar(1);
            statusbar(heatmap_builder,'indexing...');
            progressbar('indexing...');
            % undef array
            % Sorting_order = ones(size(clust_order));
            
            %for i = 1 : 1000
            for i = 1 : handles.noEntries
                Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                Weight(i) = Column2(i)
                Sorting_order(i) = clust_order(i);
                if handles.sort ~= 0,
                    NewSorting_order(i,1) = clust_order{1,i};
                    NewSorting_order(i,2) = Weight(i);
                end
                progressbar(i/handles.noEntries);
            end
            
            if handles.save_sorting_order == 1,
                handles.remember_clustering = 1;
            else 
                handles.remember_clustering = 0;
            end
            
            if handles.sort == 1,
                [Ordered, id] = sortrows(NewSorting_order, [1,2]);
            else
                [Ordered, id] = sort(Sorting_order);
            end
            
            
        % use saved sorting order;
        elseif handles.sort_options == 5,
            progressbar('Use last saved sorting order...');
            sorting_order_path = handles.sorting_order_filename;
            cluster_order_path = handles.cluster_order_filename;
            % load('~/sorting_order.mat', 'saved_Sorting_order');
            load(sorting_order_path, 'saved_Sorting_order');
            [lines,saved_ids_size] = size(saved_Sorting_order);
            if saved_ids_size == handles.noEntries
                clear('Sorting_order');
                Sorting_order = saved_Sorting_order;
                handles.Sorting_order = saved_Sorting_order;
                statusbar(heatmap_builder,'use saved sorting order...');
                
                if handles.remember_clustering == 1,
                    load(cluster_order_path, 'saved_clusters_order');
                    sorted_weight_matrix{4} = saved_clusters_order;
                    handles.clusters_order = saved_clusters_order;
                end
            else
                msgbox('Saved sorting could not be re-applied due to differences in data matrix size!\nProcess without sorting...','Warning:','warn');
                statusbar(heatmap_builder,'process without sorting according to a weight...');
            end
            [Ordered, id] = sort(Sorting_order);
        end
        
        set(sb.ProgressBar, 'Value', 60);

        progressbar(1);
        
        statusbar(heatmap_builder,'sorting according to a weight...');
        Sorted_Weights = Weight(: , id);
        SortedGenes = chr(id, :);
        SortedTranscripts = handles.Transcript_IDs(id, :);
        SortedExpression = handles.Column2(id, :);
        set(sb.ProgressBar, 'Value', 80);  
        
        
    else
        statusbar(heatmap_builder,'process without sorting according to a weight...');
        SortedGenes = chr;
        Sorted_Weights = zeros(1,handles.noEntries);
        SortedTranscripts = handles.Transcript_IDs;
        SortedExpression = handles.log2ratio;        
        set(sb.ProgressBar, 'Value', 80);

    end

    sorted_weight_matrix{1}=SortedTranscripts;
    sorted_weight_matrix{3}=Sorted_Weights;
    sorted_weight_matrix{2}=SortedExpression;
    
    if handles.sort_options == 4 || handles.sort_options == 5 ,
    sorted_weight_matrix{4}=handles.clusters_order;
    end
    
    if handles.save_clusters == 1,
    sorted_weight_matrix{5}=SortedGenes;
    end
    
    handles.sorted_weight_matrix=sorted_weight_matrix;
    if handles.save_sorting_order == 1
       statusbar(heatmap_builder,'save sorting order...');
       
       if exist ('handles.sorting_order_filename' , 'var'),
            sorting_order_path = handles.sorting_order_filename;
       else 
            sorting_order_path=fullfile(handles.current_dir,'sorting_order.mat');
       end

        if exist ('handles.cluster_order_filename' , 'var'),
            cluster_order_path = handles.cluster_order_filename;
        else 
            cluster_order_path=fullfile(handles.current_dir,'clusters_order.mat');
        end

       saved_Sorting_order=Sorting_order;
       handles.Sorting_order=Sorting_order;
       save(sorting_order_path, 'saved_Sorting_order');
       whos('-file', sorting_order_path);
       
       if handles.sort_options == 4,
            saved_clusters_order=SortedClusters;
            handles.SortedClusters=SortedClusters;
            save(cluster_order_path, 'saved_clusters_order');
            whos('-file', cluster_order_path);
       end
    end

    
    % Smooth a little the matrix, to look nicer on the heatmap
    if handles.smooth == 1
        statusbar(heatmap_builder,'"Smooth" a matrix...');
        set(sb.ProgressBar, 'Value', 90);
        handles.SmoothedGenes = smoothc(SortedGenes, 2, 1); % http://www.mathworks.com/matlabcentral/fileexchange/7951-smoothc-mat
    else
        handles.SmoothedGenes = SortedGenes;
    end
    

    statusbar(heatmap_builder,'done');
    set(sb.ProgressBar, 'Value', 100);
    
    % save analysis settings
    settings_file=fullfile(handles.current_dir,'settings.mat');

    save(settings_file,'-struct','handles',...      
        'sort_options','smooth','do_not_normalize',...      
        'use_norm','sort','save_clusters','delta_weight',...      
        'sorting_shift','sorting_shift','nr_of_clusters',...      
        'nr_of_itterations','use_cmap','save_sorting_order',...      
        'remember_clustering','treshold','apply_xlim','xlim_up');     
    disp('Contents of settings.mat:');
    whos('-file', settings_file);

    set(handles.Draw_heatmap(1),'Enable','on')
    set(handles.Draw_heatmap(2),'Enable','on')
    
guidata(gcbo, handles);
end

% --------------------------------------------------------------------
function Start_analysis_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to Start_analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    %initialize    
    noEntries = handles.noEntries;
    noNuc = handles.noNuc;
    chr = handles.chr;
    Transcript_IDs = handles.Transcript_IDs;
    Column2 = handles.Column2;
    sb = statusbar(heatmap_builder,' ');

    handles.SmoothedGenes = zeros(1,handles.noEntries);
    handles.Column2(isnan(handles.Column2)) = 1000 ;
	handles.maximum = max(max(chr));
    handles.minimum = min(min(chr));
    statusbar(heatmap_builder,'normalization...');
    set(sb.ProgressBar, 'Value', 20);
     
    % normalize
    
    selection = handles.use_norm
    switch selection
    case 'rescale_each'
        progressbar('Rescaling each lane from 0 to 1 ...');
        for i = 1 : handles.noEntries
            maximum = max(chr(i,:));
            minimum = min(chr(i,:));
            chr(i,:) = ( chr(i,:) - minimum) / (maximum-minimum);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);
    
    case 'rescale'
        progressbar('Rescaling matrix from 0 to 1 ...');
        maximum = max(max(handles.chr));
        minimum = min(min(handles.chr));
        for i = 1 : handles.noEntries
            chr(i,:) = ( chr(i,:) - minimum) / (maximum-minimum);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);
        
    case 'maximum'
        progressbar('Normalize to a maximum...');
        for i = 1 : handles.noEntries
            maximum = max(chr(i,:));
            chr(i,:) = ( chr(i,:)) / (maximum);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);
        
    case 'global_max'
        progressbar('Normalize to a gloabal maximum...');
        maximum = max(max(handles.chr));
        for i = 1 : handles.noEntries
            chr(i,:) = ( chr(i,:)) / (maximum);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = maximum;
        handles.minimum = min(min(chr));
        progressbar(1);
        
    case 'leftmost';
        progressbar('Normalize to most left value ...');
        for i = 1 : handles.noEntries
            chr(i,:) =  chr(i,:) / chr(i,1);
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);
        
    case 'treshold';
        progressbar('Remove values above a treshold...');
        for i = 1 : handles.noEntries
            for j = 1: handles.noNuc
               if chr(i,j) > handles.treshold,
                chr(i,j) = handles.treshold;
               end
            end
            progressbar(i/handles.noEntries);
        end
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
        progressbar(1);

    case 'none';
        handles.maximum = max(max(chr));
        handles.minimum = min(min(chr));
    end
    
    %plot normalized average occupancy profile
    AV2=nanmean(chr);

    maxTick=noNuc-5;
    half_TickX=round((noNuc-1)/2, -1);
    one_forth_tickX = round((noNuc-1)/4, -1);
    three_forth_tickX = round(3*(noNuc-1)/4, -1);

    % set(figure, 'MenuBar', 'none');
    x_size=700;
    y_size=600;
    bottom=100;
    left=100;
    h=figure('Position', [left, bottom, x_size+50, y_size]);
    
    plot(AV2(1,1:noNuc),'DisplayName','Average profile','YDataSource','AV2(1,1:noNuc)','LineWidth',2);
    if handles.apply_xlim == 1,
       xlim([0 handles.xlim_up]);
    else
       xlim([0 noNuc]);
    end

    set(gca, 'XTick', [1 one_forth_tickX half_TickX three_forth_tickX maxTick] );
    set(gca, 'XTickLabel', {-half_TickX,-one_forth_tickX,0,one_forth_tickX, half_TickX } );
    xlabel('Distance from feature (bp)');
    ylabel('Normalized signal');

     % save individual cluster's metagenes as PNG
    png_path = sprintf('%s%s%s%s', handles.PathName, 'aggregated_profile', '.png');
    print(h, '-dpng','-r300', png_path);


    chr(isnan(chr)) = 0.000000000001 ;

    % prepare data to plot
    % Sort genes in increasing order of the standard deviation of occupancy
    if handles.delta_weight > round((handles.noNuc-1)/2),
        msg = sprintf ('Delta can not be bigger than 1/2 of array widht!\nReplacing current value %d by %d', handles.delta_weight, round((handles.noNuc-1)/2)-1);
        handles.delta_weight = round((handles.noNuc-1)/2)-1;
        disp(handles.delta_weight);
        guidata(gcbo, handles);
    end

    if handles.delta_weight > 0,
        statusbar(heatmap_builder,'sorting according to a weight...');
        set(sb.ProgressBar, 'Value', 40);

        weight_delta=handles.delta_weight;
        shift = handles.sorting_shift;

        start_region = round((handles.noNuc-1)/2)+shift-weight_delta;
        stop_region = round((handles.noNuc-1)/2)+shift+weight_delta+1;
        Weight = zeros(1,handles.noEntries);
        
        if exist ('handles.Sorting_order' , 'var'),
            Sorting_order = handles.Sorting_order;
        else 
            Sorting_order = zeros(1,handles.noEntries);
        end
        
        id = zeros(1,handles.noEntries);

        % initialize sorting order (handles.sort_options = 0)
        progressbar('indexing...');
        for i = 1 : handles.noEntries
            Sorting_order(i) = i;
            Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
            progressbar(i/handles.noEntries);
        end
        
        % do not sort
        if handles.sort_options == 0,
             [Ordered, id] = sort(Sorting_order);
             handles.remember_clustering = 0;
        
        % use average
        elseif handles.sort_options == 1,
            statusbar(heatmap_builder,'calcualting average frequency in [-delta..+delta] region...');
            progressbar('calcualting average frequency in [-delta..+delta] region...');
            for i = 1 : handles.noEntries
                Sorting_order(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                progressbar(i/handles.noEntries);
            end
            [Ordered, id] = sort(Sorting_order);
            handles.remember_clustering = 0;
            
        % use 'StDev';
        elseif handles.sort_options == 2,
            statusbar(heatmap_builder,'calcualting St.Dev of frequency in [-delta..+delta] region...');
            progressbar('calcualte St.Dev of frequency in [-delta..+delta] region...');
            for i = 1 : handles.noEntries
                Sorting_order(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                progressbar(i/handles.noEntries);
            end
            [Ordered, id] = sort(Sorting_order);
            handles.remember_clustering = 0;
            
        % use data from col 2 to sort';    
        elseif handles.sort_options == 3,
            statusbar(heatmap_builder,'use column 2 for sorting...');
            Weight=Column2;
            tmp=transpose(Weight);
            Weight=tmp;
            [Ordered, id] = sort(Weight);
            handles.remember_clustering = 0;
            
        % use K-mean clustering; 
        elseif handles.sort_options == 4,
            statusbar(heatmap_builder,'perform K-mean clustering');
            progressbar('perform K-mean clustering');
            tic
            opts = statset('Display','final');
            [membership, ctrs, sumd, pointd] = kmeans(chr(1:handles.noEntries, start_region:stop_region),handles.nr_of_clusters,...
                        'emptyaction','drop',...
                        'Replicates',handles.nr_of_itterations,...
                        'Options',opts);
            handles.non_zero_indexes=find(sumd)
            [identified_clusters,cols]=size(handles.non_zero_indexes)
            msg = sprintf ('K-mean clustering done in %f seconds. %d clusters identifid', toc, identified_clusters);
            disp(msg);
            progressbar(1);
            statusbar(heatmap_builder,'indexing...');
            progressbar('indexing...');
            for i = 1 : handles.noEntries
                Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                Sorting_order(i) = membership(i);
                if handles.sort ~= 0,
                    NewSorting_order(i,1) = membership(i);
                    NewSorting_order(i,2) = Weight(i);
                end
                progressbar(i/handles.noEntries);
            end
            
            if handles.save_sorting_order == 1,
                handles.remember_clustering = 1;
            else 
                handles.remember_clustering = 0;
            end
            
            if handles.sort == 1,
                [Ordered, id] = sortrows(NewSorting_order, [1,2]);
            else
                [Ordered, id] = sort(Sorting_order);
            end
            SortedClusters = membership(id, :);
            handles.clusters_order = SortedClusters;
            
        % use hierarchical clustering; 
        elseif handles.sort_options == 6,
            statusbar(heatmap_builder,'Compute hierarchical clustering');
            progressbar('Compute hierarchical clustering');
            cmap_selection = handles.use_cmap
 
            c = clustergram(chr,...
                        'Cluster','column',...
                        'ColumnPDist', 'ward',...
                        'Linkage', 'complete',...
                        'OptimalLeafOrder', 'TRUE',...
                        'colormap', cmap_selection,...
                        'Dendrogram',1,...
                        'Symmetric', 'FALSE' );
                    
            clust_order=get(c, 'RowLabels')
            transposed = clust_order'
            clust_order= str2double(transposed)
            msg = sprintf ('Hierarchical clustering done in %f seconds.', toc);
            disp(msg);
            progressbar(1);
            statusbar(heatmap_builder,'indexing...');
            progressbar('indexing...');
            % undef array
            % Sorting_order = ones(size(clust_order));
            
            %for i = 1 : 1000
            for i = 1 : handles.noEntries
                Weight(i) = sum(chr(i, start_region:stop_region))/(abs(2*weight_delta)+1);
                Weight(i) = Column2(i)
                Sorting_order(i) = clust_order(i);
                if handles.sort ~= 0,
                    NewSorting_order(i,1) = clust_order{1,i};
                    NewSorting_order(i,2) = Weight(i);
                end
                progressbar(i/handles.noEntries);
            end
            
            if handles.save_sorting_order == 1,
                handles.remember_clustering = 1;
            else 
                handles.remember_clustering = 0;
            end
            
            if handles.sort == 1,
                [Ordered, id] = sortrows(NewSorting_order, [1,2]);
            else
                [Ordered, id] = sort(Sorting_order);
            end
            
            
        % use saved sorting order;
        elseif handles.sort_options == 5,
            progressbar('Use last saved sorting order...');
            sorting_order_path = handles.sorting_order_filename;
            cluster_order_path = handles.cluster_order_filename;
            % load('~/sorting_order.mat', 'saved_Sorting_order');
            load(sorting_order_path, 'saved_Sorting_order');
            [lines,saved_ids_size] = size(saved_Sorting_order);
            if saved_ids_size == handles.noEntries
                clear('Sorting_order');
                Sorting_order = saved_Sorting_order;
                handles.Sorting_order = saved_Sorting_order;
                statusbar(heatmap_builder,'use saved sorting order...');
                
                if handles.remember_clustering == 1,
                    load(cluster_order_path, 'saved_clusters_order');
                    sorted_weight_matrix{4} = saved_clusters_order;
                    handles.clusters_order = saved_clusters_order;
                end
            else
                msgbox('Saved sorting could not be re-applied due to differences in data matrix size!\nProcess without sorting...','Warning:','warn');
                statusbar(heatmap_builder,'process without sorting according to a weight...');
            end
            [Ordered, id] = sort(Sorting_order);
        end
        
        set(sb.ProgressBar, 'Value', 60);

        progressbar(1);
        
        statusbar(heatmap_builder,'sorting according to a weight...');
        Sorted_Weights = Weight(: , id);
        SortedGenes = chr(id, :);
        SortedTranscripts = handles.Transcript_IDs(id, :);
        SortedExpression = handles.Column2(id, :);
        set(sb.ProgressBar, 'Value', 80);  
        
        
    else
        statusbar(heatmap_builder,'process without sorting according to a weight...');
        SortedGenes = chr;
        Sorted_Weights = zeros(1,handles.noEntries);
        SortedTranscripts = handles.Transcript_IDs;
        SortedExpression = handles.log2ratio;        
        set(sb.ProgressBar, 'Value', 80);

    end

    sorted_weight_matrix{1}=SortedTranscripts;
    sorted_weight_matrix{3}=Sorted_Weights;
    sorted_weight_matrix{2}=SortedExpression;
    
    if handles.sort_options == 4 || handles.sort_options == 5 ,
    sorted_weight_matrix{4}=handles.clusters_order;
    end
    
    if handles.save_clusters == 1,
    sorted_weight_matrix{5}=SortedGenes;
    end
    
    handles.sorted_weight_matrix=sorted_weight_matrix;
    if handles.save_sorting_order == 1
       statusbar(heatmap_builder,'save sorting order...');
       
       if exist ('handles.sorting_order_filename' , 'var'),
            sorting_order_path = handles.sorting_order_filename;
       else 
            sorting_order_path=fullfile(handles.current_dir,'sorting_order.mat');
       end

        if exist ('handles.cluster_order_filename' , 'var'),
            cluster_order_path = handles.cluster_order_filename;
        else 
            cluster_order_path=fullfile(handles.current_dir,'clusters_order.mat');
        end

       saved_Sorting_order=Sorting_order;
       handles.Sorting_order=Sorting_order;
       save(sorting_order_path, 'saved_Sorting_order');
       whos('-file', sorting_order_path);
       
       if handles.sort_options == 4,
            saved_clusters_order=SortedClusters;
            handles.SortedClusters=SortedClusters;
            save(cluster_order_path, 'saved_clusters_order');
            whos('-file', cluster_order_path);
       end
    end

    
    % Smooth a little the matrix, to look nicer on the heatmap
    if handles.smooth == 1
        statusbar(heatmap_builder,'"Smooth" a matrix...');
        set(sb.ProgressBar, 'Value', 90);
        handles.SmoothedGenes = smoothc(SortedGenes, 2, 1); % http://www.mathworks.com/matlabcentral/fileexchange/7951-smoothc-mat
    else
        handles.SmoothedGenes = SortedGenes;
    end
    

    statusbar(heatmap_builder,'done');
    set(sb.ProgressBar, 'Value', 100);
    
    % save analysis settings
    settings_file=fullfile(handles.current_dir,'settings.mat');

    save(settings_file,'-struct','handles',...      
        'sort_options','smooth','do_not_normalize',...      
        'use_norm','sort','save_clusters','delta_weight',...      
        'sorting_shift','sorting_shift','nr_of_clusters',...      
        'nr_of_itterations','use_cmap','save_sorting_order',...      
        'remember_clustering','treshold','apply_xlim','xlim_up');     
    disp('Contents of settings.mat:');
    whos('-file', settings_file);

    set(handles.Draw_heatmap(1),'Enable','on')
    set(handles.Draw_heatmap(2),'Enable','on')
    
    guidata(gcbo, handles);
end

% --------------------------------------------------------------------
function Draw_heatmap_Callback(hObject, eventdata, handles)
% hObject    handle to Draw_heatmap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%check if matrix is loaded
if handles.matrix_loaded == 0
    h = msgbox('Matrix file is not loaded!','Warning:','warn');
else
    % popup a dilog to enter figure title
    title_string = char(inputdlg('Figure Title'));
    if size(title_string) > 0
        set(handles.Heatmap_header_field,'String',title_string)
    else
        title_string='';
    end
    handles.title_string=title_string;


    % set(figure, 'MenuBar', 'none');
    x_size=700;
    y_size=600;
    bottom=100;
    left=100;
    
    
    % generate a heatmap, splitted on clusters 
    h=figure('Position', [left, bottom, x_size+50, y_size]);
    %figure;
    % http://www.mathworks.com/matlabcentral/fileexchange/24253-customizable-heat-maps
    
    selection = handles.use_cmap
    switch selection
        case 'bone'
            colormap(bone);
        case 'red'
            load('MyRedColormap','red_cmap')
            colormap(red_cmap);
        case 'blue'
            load('MyBlueColormap','blue_cmap')
            colormap(blue_cmap);
        case 'jet'
            colormap(jet);
        case 'bone_invert'
            colormap(flipud(bone));
        case 'blue_invert'
            load('MyRedColormap','red_cmap')
            colormap(flipud(blue_cmap));
        case 'red_invert'
            load('MyBlueColormap','blue_cmap')
            colormap(flipud(red_cmap));
    end
    

        
    msg=handles.title_string;
    
    noNuc=handles.noNuc;
    maxTick=noNuc-5;
    half_TickX=round((noNuc-1)/2, -1);
    one_forth_tickX = round((noNuc-1)/4, -1);
    three_forth_tickX = round(3*(noNuc-1)/4, -1);
    
    noEntries=handles.noEntries;
    maxTickY=noEntries-10;
    half_TickY=round((noEntries-1)/2, -1);
    one_forth_tickY = round((noEntries-1)/4, -1);
    three_forth_tickY = round(3*(noEntries-1)/4, -1);
    
    central_tick = half_TickX + handles.sorting_shift;
    delta_tick=handles.delta_weight;
    
    data_mat=handles.SmoothedGenes;
    %if handles.apply_xlim == 1,
    %    mat=handles.SmoothedGenes{,0:handles.xlim_up}
    %else
    %    mat=handles.SmoothedGenes
    %end
    
    [handles.himage,handles.htext]=heatmap(...
    data_mat,...
    {1 one_forth_tickX half_TickX three_forth_tickX maxTick},...
    {1 one_forth_tickY half_TickY three_forth_tickY maxTickY},...
    [],...
    'NaNColor', [0 0 0],...
    'Colorbar', true,...
    'ColorLevels',1024,...
    'Parent', gca);

    title(msg, 'FontSize', 18)
    
    line([central_tick-delta_tick,central_tick-delta_tick],[0,noEntries],'Color','green','LineWidth',1)
    line([central_tick,central_tick],[0,noEntries],'Color','green','LineWidth',1)
    line([central_tick+delta_tick,central_tick+delta_tick],[0,noEntries],'Color','green','LineWidth',1)
    
    if handles.sort_options == 4 || handles.remember_clustering == 1,
        matrix=handles.sorted_weight_matrix;
        start_cluster=1;
        line([0 noNuc],[2 2],'LineWidth',1,'Color','red');
        line([0 noNuc],[noEntries-2 noEntries-2],'LineWidth',1,'Color','red');
        status = 0;

        % draw cluster marks
        for i = 1 : handles.noEntries
            cluster_id=matrix{1,4}(i); 
            if start_cluster <= cluster_id & status == 0
                line([0 noNuc],[i-1 i-1],'Color','red','LineWidth',1); status=1;
            elseif start_cluster == cluster_id & status == 1

            else
                start_cluster = cluster_id; status =0;
            end
        end
    end
    
    
    set(gca, 'XTick', [1 one_forth_tickX half_TickX three_forth_tickX maxTick] );
    set(gca, 'XTickLabel', {-half_TickX,-one_forth_tickX,0,one_forth_tickX, half_TickX } );
    set(gca, 'YTick', [1 one_forth_tickY half_TickY three_forth_tickY maxTickY] );
    set(gca, 'YTickLabel', {maxTickY,three_forth_tickY,half_TickY,one_forth_tickY, 0 } );
    
    %set(gca, 'XTick', [1 100 600 1100 maxTick-1] );
    %set(gca, 'XTickLabel', {-100,'TSS',500,1000, 1500 } );
    set(gca, 'FontSize', 16, 'TickLength', [0.03 0.025] );

    %set(gca, 'YTick', [1 1000 2000 3000 4000 maxTickY] );
    %set(gca, 'YTickLabel', {maxTickY,4000,3000,2000,1000,1} );
    set(gca, 'FontSize', 16, 'TickLength', [0.03 0.025] );    
 
    % save heatmap as PNG
    png_path = sprintf('%s%s%s%s', handles.PathName,'heatmap.',handles.title_string, '.png');
    print(h, '-dpng','-r300', png_path);
    
    
    handles.file_saved=0;
    
    if handles.sort_options == 4 || handles.sort_options == 5 || handles.remember_clustering == 1,
        progressbar('Calculate average profiles for all clusters...');
    

    % plot average profile for each clusters on different figure pannels
    h=figure('Position', [left, bottom,  x_size, y_size+100]);
        %msg= sprintf('%s%s%c', 'Individual profiles: ', handles.title_string );
        %legend(msg);
        %determine cluster boundaries
        k=1;start_cluster=1;status=0;
        for i = 1 : handles.noEntries
            cluster_id=matrix{1,4}(i); 
            if start_cluster <= cluster_id & status == 0
                cluster_start_index{k}=i; k=k+1; status=1;
            elseif start_cluster == cluster_id & status == 1
                
            else
                cluster_stop_index{k-1}=i;
                start_cluster = cluster_id; status =0;
            end
        end
        % number of generated clusters
        cluster_stop_index{k-1}=handles.noEntries;
        %[nr_of_clusters,cols]=size(handles.non_zero_indexes)
        nr_of_clusters = size(cluster_stop_index,2)
        for j = 1: nr_of_clusters
            nr_of_rows_on_plot = ceil(nr_of_clusters/3);
            new_matrix{j}=matrix{1,5}(cluster_start_index{j}:cluster_stop_index{j},:);
            progressbar(j/nr_of_clusters);
            
            [Cluster_noEntries, Cluster_noNuc] = size(new_matrix{j});
            
            
            AV2=nanmean(new_matrix{j});


            msg=sprintf('Cluster %d (%d entries)', j, Cluster_noEntries);
            subplot(nr_of_rows_on_plot, 3, j);
            plot(AV2(1,1:noNuc),'LineWidth',2);
            if handles.apply_xlim == 1,
                xlim([0 handles.xlim_up]);
            else
                xlim([0 noNuc]);
            end
            ylim([0 handles.maximum])
            title(msg);
            xlabel('Distance from feature (bp)');
            ylabel('Normalized signal');
            
            set(gca, 'XTick', [1 one_forth_tickX half_TickX three_forth_tickX maxTick] );
            set(gca, 'XTickLabel', {-half_TickX,-one_forth_tickX,0,one_forth_tickX, half_TickX } );
         end

    % save individual cluster's metagenes as PNG
    png_path = sprintf('%s%s%s%s', handles.PathName, 'individual profiles.',handles.title_string, '.png');
    print(h, '-dpng','-r300', png_path);

    
    % plot average profile for each clusters on the same figure
    h=figure('Position', [left, bottom,  x_size, y_size]);
        
        %determine cluster boundaries
        k=1;start_cluster=1;status=0;
        for i = 1 : handles.noEntries
            cluster_id=matrix{1,4}(i); 
            if start_cluster <= cluster_id & status == 0
                cluster_start_index{k}=i; k=k+1; status=1;
            elseif start_cluster == cluster_id & status == 1
                
            else
                cluster_stop_index{k-1}=i;
                start_cluster = cluster_id; status =0;
            end
        end
        cluster_stop_index{k-1}=handles.noEntries;
        
        for j = 1: nr_of_clusters
            nr_of_rows_on_plot = round(nr_of_clusters/2);
            new_matrix{j}=matrix{1,5}(cluster_start_index{j}:cluster_stop_index{j},:);
            %progressbar(j/handles.nr_of_clusters);
            
            %[Cluster_noEntries, Cluster_noNuc] = size(new_matrix{j});
            
            
            AV2=nanmean(new_matrix{j});
            % normalize to a first value
            % norm_factor=AV2(1);
            % for i = 1 : Cluster_noNuc
            % AV2(i) =  AV2(i)/norm_factor;
            % end
            msg= sprintf('%s%s%c', 'Average profiles: ', handles.title_string );

            legend_msgs{j}=sprintf('cluster %d', j);
            plot(AV2(1,1:noNuc),'LineWidth',1);
            hold all
            if handles.apply_xlim == 1,
                xlim([0 handles.xlim_up]);
            else
                xlim([0 noNuc]);
            end
            title(msg);
            xlabel('Distance from feature (bp)');
            ylabel('Normalized signal');
            set(gca, 'XTick', [1 one_forth_tickX half_TickX three_forth_tickX maxTick] );
            set(gca, 'XTickLabel', {-half_TickX,-one_forth_tickX,0,one_forth_tickX, half_TickX } );
        end
        legend(legend_msgs);
        hold off
        
        % save cluster's metagenes as PNG
        png_path = sprintf('%s%s%s%s', handles.PathName, 'all profiles.',handles.title_string, '.png');
        print(h, '-dpng','-r300', png_path);

    end
    
end

% save analysis settings
savefile=fullfile(handles.current_dir,'settings.mat');
save(savefile,'-struct','handles',...      
    'sort_options','smooth','do_not_normalize',...      
    'use_norm','sort','save_clusters','delta_weight',...      
    'sorting_shift','sorting_shift','nr_of_clusters',...      
    'nr_of_itterations','use_cmap','save_sorting_order',...      
    'remember_clustering','treshold','apply_xlim','xlim_up');     
disp('Contents of settings.mat:');
whos('-file', savefile);

set(handles.Save_Transcripts(1),'Enable','on')
set(handles.Save_Transcripts(2),'Enable','on')
guidata(gcbo, handles);
end
% --------------------------------------------------------------------
function Draw_heatmap_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to Draw_heatmap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%check if matrix is loaded
if handles.matrix_loaded == 0
    h = msgbox('Matrix file is not loaded!','Warning:','warn');
else
    % popup a dilog to enter figure title
    title_string = char(inputdlg('Figure Title'));
    if size(title_string) > 0
        set(handles.Heatmap_header_field,'String',title_string)
    else
        title_string='';
    end
    handles.title_string=title_string;


    % set(figure, 'MenuBar', 'none');
    x_size=700;
    y_size=600;
    bottom=100;
    left=100;
    
    
    % generate a heatmap, splitted on clusters 
    h=figure('Position', [left, bottom, x_size+50, y_size]);
    %figure;
    % http://www.mathworks.com/matlabcentral/fileexchange/24253-customizable-heat-maps
    
    selection = handles.use_cmap
    switch selection
        case 'bone'
            colormap(bone);
        case 'red'
            load('MyRedColormap','red_cmap')
            colormap(red_cmap);
        case 'blue'
            load('MyBlueColormap','blue_cmap')
            colormap(blue_cmap);
        case 'jet'
            colormap(jet);
        case 'bone_invert'
            colormap(flipud(bone));
        case 'blue_invert'
            load('MyRedColormap','red_cmap')
            colormap(flipud(blue_cmap));
        case 'red_invert'
            load('MyBlueColormap','blue_cmap')
            colormap(flipud(red_cmap));
    end
    

        
    msg=handles.title_string;
    
    noNuc=handles.noNuc;
    maxTick=noNuc-5;
    half_TickX=round((noNuc-1)/2, -1);
    one_forth_tickX = round((noNuc-1)/4, -1);
    three_forth_tickX = round(3*(noNuc-1)/4, -1);
    
    noEntries=handles.noEntries;
    maxTickY=noEntries-10;
    half_TickY=round((noEntries-1)/2, -1);
    one_forth_tickY = round((noEntries-1)/4, -1);
    three_forth_tickY = round(3*(noEntries-1)/4, -1);
    
    central_tick = half_TickX + handles.sorting_shift;
    delta_tick=handles.delta_weight;
    
    data_mat=handles.SmoothedGenes;
    %if handles.apply_xlim == 1,
    %    mat=handles.SmoothedGenes{,0:handles.xlim_up}
    %else
    %    mat=handles.SmoothedGenes
    %end
    
    [handles.himage,handles.htext]=heatmap(...
    data_mat,...
    {1 one_forth_tickX half_TickX three_forth_tickX maxTick},...
    {1 one_forth_tickY half_TickY three_forth_tickY maxTickY},...
    [],...
    'NaNColor', [0 0 0],...
    'Colorbar', true,...
    'ColorLevels',1024,...
    'Parent', gca);

    title(msg, 'FontSize', 18)
    
    line([central_tick-delta_tick,central_tick-delta_tick],[0,noEntries],'Color','green','LineWidth',1)
    line([central_tick,central_tick],[0,noEntries],'Color','green','LineWidth',1)
    line([central_tick+delta_tick,central_tick+delta_tick],[0,noEntries],'Color','green','LineWidth',1)
    
    if handles.sort_options == 4 || handles.remember_clustering == 1,
        matrix=handles.sorted_weight_matrix;
        start_cluster=1;
        line([0 noNuc],[2 2],'LineWidth',1,'Color','red');
        line([0 noNuc],[noEntries-2 noEntries-2],'LineWidth',1,'Color','red');
        status = 0;

        % draw cluster marks
        for i = 1 : handles.noEntries
            cluster_id=matrix{1,4}(i); 
            if start_cluster <= cluster_id & status == 0
                line([0 noNuc],[i-1 i-1],'Color','red','LineWidth',1); status=1;
            elseif start_cluster == cluster_id & status == 1

            else
                start_cluster = cluster_id; status =0;
            end
        end
    end
    
    
    set(gca, 'XTick', [1 one_forth_tickX half_TickX three_forth_tickX maxTick] );
    set(gca, 'XTickLabel', {-half_TickX,-one_forth_tickX,0,one_forth_tickX, half_TickX } );
    set(gca, 'YTick', [1 one_forth_tickY half_TickY three_forth_tickY maxTickY] );
    set(gca, 'YTickLabel', {maxTickY,three_forth_tickY,half_TickY,one_forth_tickY, 0 } );
    
    %set(gca, 'XTick', [1 100 600 1100 maxTick-1] );
    %set(gca, 'XTickLabel', {-100,'TSS',500,1000, 1500 } );
    set(gca, 'FontSize', 16, 'TickLength', [0.03 0.025] );

    %set(gca, 'YTick', [1 1000 2000 3000 4000 maxTickY] );
    %set(gca, 'YTickLabel', {maxTickY,4000,3000,2000,1000,1} );
    set(gca, 'FontSize', 16, 'TickLength', [0.03 0.025] );    
 
    % save heatmap as PNG
    png_path = sprintf('%s%s%s%s', handles.PathName,'heatmap.',handles.title_string, '.png');
    print(h, '-dpng','-r300', png_path);
    
    
    handles.file_saved=0;
    
    if handles.sort_options == 4 || handles.sort_options == 5 || handles.remember_clustering == 1,
        progressbar('Calculate average profiles for all clusters...');
    

    % plot average profile for each clusters on different figure pannels
    h=figure('Position', [left, bottom,  x_size, y_size+100]);
        %msg= sprintf('%s%s%c', 'Individual profiles: ', handles.title_string );
        %legend(msg);
        %determine cluster boundaries
        k=1;start_cluster=1;status=0;
        for i = 1 : handles.noEntries
            cluster_id=matrix{1,4}(i); 
            if start_cluster <= cluster_id & status == 0
                cluster_start_index{k}=i; k=k+1; status=1;
            elseif start_cluster == cluster_id & status == 1
                
            else
                cluster_stop_index{k-1}=i;
                start_cluster = cluster_id; status =0;
            end
        end
        % number of generated clusters
        cluster_stop_index{k-1}=handles.noEntries;
        %[nr_of_clusters,cols]=size(handles.non_zero_indexes)
        nr_of_clusters = size(cluster_stop_index,2)
        for j = 1: nr_of_clusters
            nr_of_rows_on_plot = ceil(nr_of_clusters/3);
            new_matrix{j}=matrix{1,5}(cluster_start_index{j}:cluster_stop_index{j},:);
            progressbar(j/nr_of_clusters);
            
            [Cluster_noEntries, Cluster_noNuc] = size(new_matrix{j});
            
            
            AV2=nanmean(new_matrix{j});


            msg=sprintf('Cluster %d (%d entries)', j, Cluster_noEntries);
            subplot(nr_of_rows_on_plot, 3, j);
            plot(AV2(1,1:noNuc),'LineWidth',2);
            if handles.apply_xlim == 1,
                xlim([0 handles.xlim_up]);
            else
                xlim([0 noNuc]);
            end
            ylim([0 handles.maximum])
            title(msg);
            xlabel('Distance from feature (bp)');
            ylabel('Normalized signal');
            
            set(gca, 'XTick', [1 one_forth_tickX half_TickX three_forth_tickX maxTick] );
            set(gca, 'XTickLabel', {-half_TickX,-one_forth_tickX,0,one_forth_tickX, half_TickX } );
         end

    % save individual cluster's metagenes as PNG
    png_path = sprintf('%s%s%s%s', handles.PathName, 'individual profiles.',handles.title_string, '.png');
    print(h, '-dpng','-r300', png_path);

    
    % plot average profile for each clusters on the same figure
    h=figure('Position', [left, bottom,  x_size, y_size]);
        
        %determine cluster boundaries
        k=1;start_cluster=1;status=0;
        for i = 1 : handles.noEntries
            cluster_id=matrix{1,4}(i); 
            if start_cluster <= cluster_id & status == 0
                cluster_start_index{k}=i; k=k+1; status=1;
            elseif start_cluster == cluster_id & status == 1
                
            else
                cluster_stop_index{k-1}=i;
                start_cluster = cluster_id; status =0;
            end
        end
        cluster_stop_index{k-1}=handles.noEntries;
        
        for j = 1: nr_of_clusters
            nr_of_rows_on_plot = round(nr_of_clusters/2);
            new_matrix{j}=matrix{1,5}(cluster_start_index{j}:cluster_stop_index{j},:);
            %progressbar(j/handles.nr_of_clusters);
            
            %[Cluster_noEntries, Cluster_noNuc] = size(new_matrix{j});
            
            
            AV2=nanmean(new_matrix{j});
            % normalize to a first value
            % norm_factor=AV2(1);
            % for i = 1 : Cluster_noNuc
            % AV2(i) =  AV2(i)/norm_factor;
            % end
            msg= sprintf('%s%s%c', 'Average profiles: ', handles.title_string );

            legend_msgs{j}=sprintf('cluster %d', j);
            plot(AV2(1,1:noNuc),'LineWidth',1);
            hold all
            if handles.apply_xlim == 1,
                xlim([0 handles.xlim_up]);
            else
                xlim([0 noNuc]);
            end
            title(msg);
            xlabel('Distance from feature (bp)');
            ylabel('Normalized signal');
            set(gca, 'XTick', [1 one_forth_tickX half_TickX three_forth_tickX maxTick] );
            set(gca, 'XTickLabel', {-half_TickX,-one_forth_tickX,0,one_forth_tickX, half_TickX } );
        end
        legend(legend_msgs);
        hold off
        
        % save cluster's metagenes as PNG
        png_path = sprintf('%s%s%s%s', handles.PathName, 'all profiles.',handles.title_string, '.png');
        print(h, '-dpng','-r300', png_path);

    end
    
end

% save analysis settings
savefile=fullfile(handles.current_dir,'settings.mat');
save(savefile,'-struct','handles',...      
    'sort_options','smooth','do_not_normalize',...      
    'use_norm','sort','save_clusters','delta_weight',...      
    'sorting_shift','sorting_shift','nr_of_clusters',...      
    'nr_of_itterations','use_cmap','save_sorting_order',...      
    'remember_clustering','treshold','apply_xlim','xlim_up');     
disp('Contents of settings.mat:');
whos('-file', savefile);


set(handles.Save_Transcripts(1),'Enable','on')
set(handles.Save_Transcripts(2),'Enable','on')

guidata(gcbo, handles);
end


% --------------------------------------------------------------------
function SaveImage_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to SaveImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[FileName, PathName]=uiputfile({'*.png';'*.jpg';'*.tif';'*.gif';'*.*' },'Save Image',handles.InFileName);

if isequal(FileName,0) || isequal(PathName,0)
    set(handles.file_path_field,'String','heatmap have not been saved!');
    handles.file_saved=0;
else
    OutFileName=fullfile(PathName,FileName);
    saveas(handles.himage, OutFileName);
    msg= sprintf('%s%s', 'heatmap saved to: ',OutFileName);
    set(handles.file_path_field,'String',msg);
    handles.file_saved=1;
end

% save analysis settings
savefile=fullfile(handles.current_dir,'settings.mat');
save(savefile,'-struct','handles',...      
    'sort_options','smooth','do_not_normalize',...      
    'use_norm','sort','save_clusters','delta_weight',...      
    'sorting_shift','sorting_shift','nr_of_clusters',...      
    'nr_of_itterations','use_cmap','save_sorting_order',...      
    'remember_clustering','treshold','apply_xlim','xlim_up');     
disp('Contents of settings.mat:');
whos('-file', savefile);

guidata(gcbo, handles);
end 


% --------------------------------------------------------------------
function Save_Transcripts_Callback(hObject, eventdata, handles)
% hObject    handle to Save_Transcripts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[FileName, PathName]=uiputfile({'*.txt';'*.*' },'Save Matrix',handles.InFileName)
sb = statusbar(heatmap_builder,' ');
if isequal(FileName,0) || isequal(PathName,0)
    set(handles.file_path_field,'String','Weight matrix was not saved!');
else
    OutFileName=fullfile(PathName,FileName);
    matrix=handles.sorted_weight_matrix;
    [nrows,ncols]= size(matrix);
    set(sb.ProgressBar, 'Value', 0);
    if handles.sort_options == 4 || handles.sort_options == 5 || handles.remember_clustering == 1,
        statusbar(heatmap_builder,'saving occupancy values by clusters, please wait...');   
        progressbar('saving occupancy values by clusters, please wait...');

        %T = table(matrix{1,2}(:), matrix{1,3}(:), matrix{1,4}(:), 'RowNames', matrix{1,1}(:,1))
        %writetable(T, fid(matrix{1,4}(row)), 'WriteVariableNames', 0, 'WriteRowNames',1, 'Delimiter', '\t');
      
        for cluster_id=1:handles.nr_of_clusters,
            cluster_filename = sprintf('%s%s%d%s%s',PathName,'cluster',cluster_id,'.',FileName);
            fid(cluster_id) = fopen(cluster_filename, 'w');
            if handles.save_clusters == 1,
                profile_filename = sprintf('%s%s%d%s%s',PathName,'aligned_occup.cluster',cluster_id,'.',FileName);
                Occ_fid(cluster_id) = fopen(profile_filename, 'w');
            end
        end
        
        for row=1:handles.noEntries,
            fprintf(fid(matrix{1,4}(row)), '%s\t%f\t%f\t%f\n', table2array(matrix{1,1}{row,1}) , matrix{1,2}(row), matrix{1,3}(row), matrix{1,4}(row) );
            formatString=sprintf('%s\\t%s','%s',handles.OutputFormatString);
            fprintf(Occ_fid(matrix{1,4}(row)), formatString, table2array(matrix{1,1}{row,1}) , matrix{1,2}(row), matrix{1,5}(row,:),'' );
            progressbar(row/handles.noEntries);
        end
        
        for cluster_id=1:handles.nr_of_clusters,
            fclose(fid(cluster_id));
            if handles.save_clusters == 1,
                fclose(Occ_fid(cluster_id));
            end
        end
        progressbar(1);

    else
        fid = fopen(OutFileName, 'w');
        
        progressbar('saving occupancy values by clusters, please wait...');

        for row=1:handles.noEntries, 
            progress = 100 * row / handles.noEntries;
            set(sb.ProgressBar, 'Value', progress);
            fprintf(fid, '%s\t%s\t%s\n', matrix{1,1}{row,1} , matrix{1,2}(row), matrix{1,3}(row) );
            progressbar(row/handles.noEntries);
        end
        fclose(fid);
        progressbar(1);

    end
    
    
    msg= sprintf('%s%s', 'weight matrixes saved to: ',OutFileName);
    statusbar(heatmap_builder,msg);
    set(handles.file_path_field,'String',msg);
end

% save analysis settings
savefile=fullfile(handles.current_dir,'settings.mat');
save(savefile,'-struct','handles',...      
    'sort_options','smooth','do_not_normalize',...      
    'use_norm','sort','save_clusters','delta_weight',...      
    'sorting_shift','sorting_shift','nr_of_clusters',...      
    'nr_of_itterations','use_cmap','save_sorting_order',...      
    'remember_clustering','treshold','apply_xlim','xlim_up');     
disp('Contents of settings.mat:');
whos('-file', savefile);

guidata(gcbo, handles);
end
% --------------------------------------------------------------------
function Save_Transcripts_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to Save_Transcripts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[FileName, PathName]=uiputfile({'*.txt';'*.*' },'Save Matrix',handles.InFileName)
sb = statusbar(heatmap_builder,' ');
if isequal(FileName,0) || isequal(PathName,0)
    set(handles.file_path_field,'String','Weight matrix was not saved!');
else
    OutFileName=fullfile(PathName,FileName);
    matrix=handles.sorted_weight_matrix;
    [nrows,ncols]= size(matrix);
    set(sb.ProgressBar, 'Value', 0);
    if handles.sort_options == 4 || handles.sort_options == 5 || handles.remember_clustering == 1,
        statusbar(heatmap_builder,'saving occupancy values by clusters, please wait...');   
        progressbar('saving occupancy values by clusters, please wait...');

        %T = table(matrix{1,2}(:), matrix{1,3}(:), matrix{1,4}(:), 'RowNames', matrix{1,1}(:,1))
        %writetable(T, fid(matrix{1,4}(row)), 'WriteVariableNames', 0, 'WriteRowNames',1, 'Delimiter', '\t');
      
        for cluster_id=1:handles.nr_of_clusters,
            cluster_filename = sprintf('%s%s%d%s%s',PathName,'cluster',cluster_id,'.',FileName);
            fid(cluster_id) = fopen(cluster_filename, 'w');
            if handles.save_clusters == 1,
                profile_filename = sprintf('%s%s%d%s%s',PathName,'aligned_occup.cluster',cluster_id,'.',FileName);
                Occ_fid(cluster_id) = fopen(profile_filename, 'w');
            end
        end
        
        for row=1:handles.noEntries,
            fprintf(fid(matrix{1,4}(row)), '%s\t%f\t%f\t%f\n', table2array(matrix{1,1}{row,1}) , matrix{1,2}(row), matrix{1,3}(row), matrix{1,4}(row) );
            formatString=sprintf('%s\\t%s','%s',handles.OutputFormatString);
            fprintf(Occ_fid(matrix{1,4}(row)), formatString, table2array(matrix{1,1}{row,1}) , matrix{1,2}(row), matrix{1,5}(row,:),'' );
            progressbar(row/handles.noEntries);
        end
        
        for cluster_id=1:handles.nr_of_clusters,
            fclose(fid(cluster_id));
            if handles.save_clusters == 1,
                fclose(Occ_fid(cluster_id));
            end
        end
        progressbar(1);

    else
        fid = fopen(OutFileName, 'w');
        
        progressbar('saving occupancy values by clusters, please wait...');

        for row=1:handles.noEntries, 
            progress = 100 * row / handles.noEntries;
            set(sb.ProgressBar, 'Value', progress);
            fprintf(fid, '%s\t%s\t%s\n', matrix{1,1}{row,1} , matrix{1,2}(row), matrix{1,3}(row) );
            progressbar(row/handles.noEntries);
        end
        fclose(fid);
        progressbar(1);

    end
    
    
    msg= sprintf('%s%s', 'weight matrixes saved to: ',OutFileName);
    statusbar(heatmap_builder,msg);
    set(handles.file_path_field,'String',msg);
end

% save analysis settings
savefile=fullfile(handles.current_dir,'settings.mat');
save(savefile,'-struct','handles',...      
    'sort_options','smooth','do_not_normalize',...      
    'use_norm','sort','save_clusters','delta_weight',...      
    'sorting_shift','sorting_shift','nr_of_clusters',...      
    'nr_of_itterations','use_cmap','save_sorting_order',...      
    'remember_clustering','treshold','apply_xlim','xlim_up');     
disp('Contents of settings.mat:');
whos('-file', savefile);

guidata(gcbo, handles);
end


% --------------------------------------------------------------------
function Exit_Button_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to Exit_Button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% check if image was saved before exit
savefile=fullfile(handles.current_dir,'settings.mat');
delete(savefile);
close(handles.heatmap_builder)
end


% --------------------------------------------------------------------
function Exit_Button_Callback(hObject, eventdata, handles)
% hObject    handle to Exit_Button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

savefile=fullfile(handles.current_dir,'settings.mat');
delete(savefile);
close(handles.heatmap_builder)
end

% --------------------------------------------------------------------
function File_menu_Callback(hObject, eventdata, handles)
% hObject    handle to File_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(gcbo, handles);
end


% --------------------------------------------------------------------
function Tools_menu_Callback(hObject, eventdata, handles)
% hObject    handle to Tools_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(gcbo, handles);
end


% --- Executes when user attempts to close heatmap_builder.
function heatmap_builder_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to heatmap_builder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
savefile=fullfile(handles.current_dir,'settings.mat');
delete(savefile);
close(handles.heatmap_builder)
delete(hObject);
end



% --------------------------------------------------------------------
function Help_menu_Callback(hObject, eventdata, handles)
% hObject    handle to Help_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(gcbo, handles);
end


% --------------------------------------------------------------------
function Help_Button_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to Help_Button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

winopen(handles.pdf);
guidata(gcbo, handles);
end


% --------------------------------------------------------------------
function Open_maual_Callback(hObject, eventdata, handles)
% hObject    handle to Open_maual (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

winopen(handles.pdf);
guidata(gcbo, handles);
end
