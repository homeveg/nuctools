ClusterMaps Builder
______________________

Installation:
______________________

1. Unpack ClusterMaps_Builder.v2.zip
2. Unpack and install the MATLAB Compiler Runtime (MCRInstaller.zip)
3. Start CluterMaps Builder Applition


Usage instruction:
______________________
1. To start analysis press the button "Load matrix"

Input file should contain tab-delimited table in the following format without header:

Transcript ID  | Transcript expression or other numerical characteristic to apply sorting | columns 3 to 4003 occupancy values GTX_8723648726	0.1231	1	0	1	8	�	0	0	2

If input matrix has wrong format, error message will be displayed.

2. NOTE: All analysis settings should e specified before starting analysis. 
On the panel below buttons, one can specify delta and shift from the center of the matrix. Delta defines an area which will be used for calculating average occupancy and to perform clustering when corresponding settings used.

On the panel "sorting options", one can choose between different modes of profiles sorting inside heat map. When "Hierarchical Clustering" selected as a sorting option, one should specify maximum Nr. of expected clusters.

3.  Press "Start analysis button". Depending on a data matrix size and sorting option selected data evaluation may take significant amount of time.
NOTE: Do not load more than 500MBs data files when applying hierarchical clustering. For sorting options other than clustering, tested maximum data site is about 8Gb.
 
4. After analysis is finished, press "Draw heatmap" to generate corresponding heat map image
5. "Save Transcript IDs" button invoke standard "Save As�" dialog which allows to save a list of IDs together with corresponding average occupancy values and values from column 2 of input file, sorted according to selected criteria. If clustering is used and "save clustered profile" option selected, program will create output files for each cluster.

5. "Save Image" allows to save a heat map image as a *. png or *.eps.
