while (<>) {};
print $.,"\n";
